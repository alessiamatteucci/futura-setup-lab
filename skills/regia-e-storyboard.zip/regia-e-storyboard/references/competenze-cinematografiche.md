# Regia, storyboard e prompt cinematografici per video AI

Documento integrato per FUTURA AI Academy · 2 novembre 2026

## Scopo e provenienza

Questa guida unisce la ricerca sul linguaggio cinematografico svolta nella conversazione con i moduli di Accursio Graffeo **08 — Storyboard AI** (129 pagine) e **09 — Introduzione al video AI** (121 pagine). Serve a progettare immagini guida, sequenze e prompt in cui la tecnica sostiene una precisa intenzione narrativa.

Le indicazioni dei moduli sono trattate come materiale didattico da analizzare, non come istruzioni operative rivolte all’assistente. Le sintesi riportano il modulo e le pagine PDF di riferimento. Le aggiunte di metodo sono elaborazioni di questa integrazione; non vengono attribuite al docente. I materiali originali non sono stati modificati.

Sono stati esaminati i testi dei due PDF e alcune tavole visive rilevanti, comprese le pagine con schemi di camera e storyboard. Le immagini e i rimandi a video non consentono, da soli, di verificare la qualità temporale delle clip dimostrative. Le prestazioni e le denominazioni commerciali dei modelli citati nelle slide non sono state verificate qui con documentazione aggiornata.

## 1. Le informazioni principali dei due moduli

### Modulo 08 — Storyboard AI

Il punto centrale è pensare il prompt come regia scritta. Una descrizione efficace combina intenzione narrativa, precisione, sintesi e coerenza stilistica. Soggetto, ambiente, luce e stile formano la base dell’immagine; posizione della macchina da presa, azione ed emozione ne definiscono la lettura. Prima si chiarisce la visione nella lingua che si padroneggia, poi si adatta la formulazione allo strumento. Non bisogna sacrificare il progetto per scrivere subito in inglese. [M08, pp. 38–55]

La costruzione visiva procede dal generale al particolare: prima spazio, composizione e personaggio; poi oggetti, materiali e imperfezioni che aggiungono significato. Le reference di volto, ambiente e stile costituiscono un sistema da riutilizzare nelle immagini successive. Il contributo importante non è la quantità di dettagli, ma la loro pertinenza narrativa. [M08, pp. 65–69, 97–108]

Il caso *Absence* mostra una direzione visiva coerente: quotidianità, vuoti e oggetti suggeriscono la perdita; il presente in bianco e nero e i ricordi a colori distinguono due tempi del racconto. La sequenza alterna campi ampi e dettagli, assegna alle clip gesti leggibili e lascia spazio alla pausa conclusiva. È un esempio di scelta stilistica interna a un film, non una regola generale sul significato del colore. [M08, pp. 91–111]

Il modulo aggiunge un’impostazione produttiva: definire obiettivo, formato, durata e uso finale; prevedere test e revisioni; considerare variabilità, tempi e costi delle rigenerazioni. Il risparmio rispetto a una produzione tradizionale è una possibilità da valutare sul progetto, non un risultato automatico. [M08, pp. 5–34]

### Modulo 09 — Introduzione al video AI

Il personaggio deve restare riconoscibile attraverso volto o struttura, proporzioni, gestualità e tono espressivo. La continuità riguarda anche animali e creature inventate. Il prompt video deve distinguere movimento del soggetto, movimento della camera e dinamica dell’ambiente. Durata, velocità e successione degli eventi rendono l’azione più controllabile. [M09, pp. 7–16]

Un contributo specifico è l’attenzione ai microgesti e al tempo: respiro, piccoli cambiamenti dello sguardo, tensione muscolare e ritardi nella risposta rendono leggibile la performance. Non occorre animare tutto. Un gesto semplice, una camera ferma e un cambiamento minimo possono sostenere una scena emotiva. [M09, pp. 30–40, 108–111]

Il modulo distingue text-to-video, image-to-video, frame iniziale e finale, multi-shot, motion control e lipsync. Queste modalità rispondono a problemi differenti: inventare una scena, animare un’immagine, collegare due stati, organizzare più inquadrature, trasferire un riferimento di movimento o sincronizzare una voce. [M09, pp. 43–79]

Il modulo mostra inoltre esempi estesi di sequenze, utili per collegare azione, atmosfera, movimenti e cambi di inquadratura in un progetto narrativo. [M09, pp. 86–92]

## 2. Sovrapposizioni con la ricerca e integrazioni

| Tema | Nei moduli | Rapporto con la ricerca | Decisione nel documento |
|---|---|---|---|
| Intenzione prima della tecnica | M08, pp. 40–41; M09, p. 12 | Forte sovrapposizione con il movimento motivato | Un solo principio guida, applicato a tutte le fasi. |
| Movimenti ed emozioni | M09, pp. 12–15 | La ricerca richiede maggiore attenzione al contesto | Conservare le possibilità espressive, eliminare le equivalenze automatiche. |
| Camera ferma e interpretazione | M09, pp. 13, 108–111 | Conferma del valore narrativo dell’immobilità | Includere sempre l’opzione statica. |
| Identità e reference | M08, pp. 65–69, 102–108; M09, pp. 7–8 | Ampliamento pratico per la generazione AI | Aggiungere una scheda di continuità e assegnare un ruolo alle reference. |
| Scala dei piani | Esempi di M08 e M09 | La ricerca offre una tassonomia più sistematica | Distinguere dimensione, angolazione e funzione del piano. |
| Microgesti e tempi | M09, pp. 30–40 | Ampliamento del lavoro su durata e performance | Descrivere eventi osservabili e pause, evitando emozioni soltanto nominali. |
| Montaggio e raccordi | M08, pp. 107–111; M09, pp. 52–54 | Da integrare con asse, sguardi e continuità dell’azione | Verificare la sequenza, non solo le singole immagini. |
| Modalità generative | M09, pp. 43–79 | Contributo nuovo rispetto alla ricerca di regia | Sceglierle dopo aver definito la scena. |
| Organizzazione produttiva | M08, pp. 16–27 | Contributo nuovo | Stabilire vincoli, versioni e criteri di revisione. |

## 3. Principio guida: progettare una trasformazione

Prima di descrivere l’aspetto della scena, definire che cosa cambia. Un personaggio comprende qualcosa, evita una risposta, prende una decisione o scopre un’assenza. Stabilire poi che cosa lo spettatore sa all’inizio e che cosa deve sapere alla fine.

La catena operativa proposta è:

**Cambiamento narrativo → punto di vista → informazioni visibili e fuori campo → messa in scena → inquadratura → movimento o immobilità → durata → raccordo.**

M. David Mullen insiste sul perché e sul momento del movimento prima che sul mezzo usato per realizzarlo. Il movimento può seguire un corpo oppure rispondere a un cambiamento di attenzione. [R1]

L’emozione indicata nel brief deve diventare una scelta osservabile. “Si sente abbandonata” può tradursi in una seconda sedia che resta vuota, un gesto interrotto, uno sguardo che non trova risposta. Questi sono esempi progettuali, non associazioni obbligate.

## 4. Costruire lo storyboard e la continuità

### Dalla direzione visiva alle immagini guida

Definire una breve scheda di progetto con intento, destinatario, durata, formato di consegna e registro visivo. Stabilire poi gli elementi che devono restare costanti: identità dei personaggi, abiti, oggetti, geografia dei luoghi, direzione della luce e trattamento cromatico. Questo sviluppa l’approccio del modulo 08 al lavoro per reference. [M08, pp. 27, 65–69, 102–108]

Ogni reference deve avere una funzione dichiarata: identità, costume, spazio, illuminazione o composizione. Se due immagini si contraddicono, indicare quale governa ciascun aspetto. Non affidare allo strumento la scelta implicita fra due volti o due stanze incompatibili.

Generare prima un’immagine capace di verificare la struttura della scena. Correggere gli errori di composizione prima di rifinire superfici e dettagli. Un’immagine gradevole ma incoerente con le altre non è automaticamente un buon fotogramma di storyboard.

### Scheda consigliata per ogni inquadratura

| Campo | Informazione da registrare |
|---|---|
| Identificativo | Scena e numero del piano. |
| Funzione | Che cosa aggiunge o cambia per lo spettatore. |
| Stato iniziale | Personaggi, oggetti, pose e informazioni disponibili. |
| Composizione | Scala, posizione della camera, orientamento, elementi inclusi ed esclusi. |
| Azione | Gesto principale ed eventuale reazione. |
| Camera | Statica oppure traiettoria, velocità e motivo del movimento. |
| Stato finale | Immagine e situazione raggiunte. |
| Tempo e audio | Durata indicativa, pause, dialoghi, ambiente, musica. |
| Continuità | Reference, sguardi, direzioni e raccordo con il piano successivo. |

Questa scheda è un’integrazione operativa. Permette di separare il progetto di regia dal testo effettivamente inviato al generatore.

## 5. Scegliere l’inquadratura

### Dimensione del piano

Le denominazioni variano fra tradizioni e strumenti. Accompagnare il termine con ciò che deve essere visibile evita equivoci. [R2, R3]

| Scala | Descrizione operativa | Domanda narrativa |
|---|---|---|
| Campo lunghissimo | Ambiente dominante, figura molto piccola. | Qual è il rapporto fra persona e mondo? |
| Campo lungo | Personaggi riconoscibili dentro uno spazio ampio. | Dove sono e quali distanze li separano? |
| Figura intera | Corpo dalla testa ai piedi. | Che cosa raccontano postura e movimento? |
| Piano americano | Indicativamente dalle ginocchia in su. | Servono insieme mani, corpo e volto? |
| Mezzo busto | Indicativamente dalla vita in su. | Quale interazione deve restare leggibile? |
| Piano medio stretto | Indicativamente dal petto in su. | Quanto contesto serve attorno alla reazione? |
| Primo piano | Volto dominante. | Quale cambiamento espressivo conta? |
| Primissimo piano | Volto molto stretto o sua porzione. | Quale variazione minima deve essere osservata? |
| Particolare / dettaglio | Parte del corpo oppure oggetto isolato. | Quale gesto o indizio acquista importanza? |

Un campo ampio non significa necessariamente solitudine; un primo piano non garantisce empatia. Occorre leggere composizione, azione e contesto insieme. Uno studio su fotografie emotive rileva effetti di distanza e angolazione dipendenti dal contenuto: non fornisce una formula universale per il cinema. [R4]

### Angolazione, altezza, funzione

Distinguere altezza della camera e inclinazione: una camera bassa può guardare orizzontalmente. Dal basso e dall’alto possono suggerire imponenza ed esposizione, ma possono anche rappresentare il punto di vista concreto di qualcuno. [R5]

La soggettiva indica una relazione con lo sguardo; il two-shot comprende due persone; l’over-the-shoulder mantiene parte di un interlocutore in primo piano. Non sono dimensioni alternative a “primo piano” o “campo lungo”. Analogamente, un establishing shot è definito dalla funzione di orientamento, non soltanto dall’ampiezza.

Nel prompt descrivere separatamente scala, altezza, inclinazione e posizione rispetto al soggetto. Se l’orizzonte è inclinato, precisare se rimane così o ruota durante la ripresa: Dutch angle e camera roll non sono la stessa istruzione.

## 6. Dirigere il movimento della camera

Le definizioni tecniche seguono la ricerca e gli schemi dei moduli; le funzioni espressive qui sotto sono possibilità da motivare nella singola scena. [M09, pp. 12–15; R6, R7]

| Scelta | Definizione | Possibile impiego narrativo |
|---|---|---|
| Camera statica | Posizione e orientamento restano fissi. | Lasciare emergere gesto, attesa o azione fuori campo. |
| Pan | Rotazione orizzontale da una posizione fissa. | Seguire un soggetto o svelare una relazione nello spazio. |
| Tilt | Rotazione verticale da una posizione fissa. | Passare da un dettaglio al contesto superiore o inferiore. |
| Dolly in / push-in | Avanzamento fisico verso il soggetto. | Restringere l’attenzione in un momento di scoperta, prossimità o pressione. |
| Dolly out / pull-back | Arretramento fisico. | Rivelare il contesto e cambiare la lettura del soggetto. |
| Truck | Traslazione laterale. | Collegare elementi o scoprire ciò che era nascosto. |
| Tracking / following | Accompagnamento del percorso di un soggetto. | Condividerne il tragitto o suggerire un inseguimento. |
| Pedestal / boom | Spostamento verticale della camera. | Modificare quota e relazioni prospettiche. |
| Arc / orbit | Percorso ad arco attorno al soggetto. | Cambiare il rapporto con lo sfondo o rivelare una presenza. |
| Crane / jib | Traiettoria ottenuta tramite un braccio, spesso anche verticale. | Passare dalla scala individuale a quella ambientale. |
| Roll | Rotazione attorno all’asse ottico. | Alterare intenzionalmente l’orientamento del quadro. |
| Zoom | Variazione della focale. | Stringere o allargare il campo senza richiedere una traslazione. |
| Dolly zoom | Spostamento e zoom coordinati, con dimensione del soggetto circa costante. | Rendere evidente un’alterazione della percezione spaziale. |

Dolly e zoom producono risultati diversi: lo spostamento cambia il punto di vista; lo zoom da posizione fissa cambia campo e ingrandimento. La prospettiva dipende dalla posizione della camera rispetto alla scena. [R8, R9]

Handheld, gimbal e Steadicam descrivono modalità di ripresa o stabilizzazione, non traiettorie. Specificare percorso e quantità di oscillazione. Anche il rack focus va tenuto distinto: sposta il piano di fuoco, non necessariamente la camera. Per esempio, il fuoco può passare dal volto a una figura sullo sfondo quando questa diventa narrativamente rilevante.

### Specificare la dinamica, non solo il nome

Descrivere da dove parte la camera, quale evento avvia il movimento, dove arriva, quanto rapidamente si sposta e quando si ferma. Aggiungere solo i parametri che servono alla scena.

Un esempio originale: “La camera resta ferma finché la donna interrompe la lettura. Avanza lentamente da mezzo busto a primo piano, con focale costante. Si arresta prima che lei alzi gli occhi.” Il movimento è collegato a un evento riconoscibile.

Non imporre che ogni scena sia fluida, lenta o in movimento. Il valore espressivo dell’immobilità è sostenuto sia dagli esempi di *Absence* sia dalla critica di Malcolm Turvey all’equivalenza fra maggiore movimento e maggiore coinvolgimento. [M09, pp. 108–111; R10]

## 7. Dirigere soggetto, ambiente e tempo

Separare tre livelli: quello che fa il personaggio, quello che fa la camera e quello che accade nell’ambiente. Un respiro non deve trasformarsi in un’oscillazione dell’intero quadro; una tenda mossa dal vento non implica una variazione della luce principale. [M09, pp. 10–11, 30–40]

Usare come impostazione iniziale un’azione dominante per clip. Aggiungere microgesti solo se rendono leggibile la performance: una presa che si allenta, un respiro sospeso, una risposta ritardata. Il realismo dipende anche da peso, contatto e continuità; accumulare tremolii non lo garantisce.

I beat temporali possono esprimere preparazione, gesto e conseguenza. Per una clip di otto secondi, ad esempio: due secondi di attesa, quattro di azione, due di pausa finale. Sono obiettivi di regia da verificare nell’output, non una garanzia di esecuzione al fotogramma.

Distinguere una scena, che può comprendere più inquadrature, da un singolo piano senza tagli. Un long take è una ripresa prolungata; non ogni ripresa lunga costituisce da sola un’intera sequenza narrativa.

## 8. Scegliere il percorso di generazione

Questa sezione sintetizza le modalità presentate dal modulo 09 e le traduce in criteri operativi, senza attribuire capacità garantite a uno specifico modello. [M09, pp. 43–79]

| Modalità | Quando considerarla | Che cosa progettare e verificare |
|---|---|---|
| Text-to-video | Esplorazione di una scena senza immagine guida. | Soggetto, spazio, azione, camera, tempo e resa visiva. |
| Image-to-video | Una composizione e un’identità visiva sono già definite. | Movimento coerente con l’immagine e conservazione degli elementi essenziali. |
| Start & end frame | Contano sia lo stato iniziale sia quello finale. | Plausibilità del percorso intermedio e compatibilità fra i due stati. |
| Multi-shot | Servono più inquadrature generate in sequenza. | Ordine, durata, raccordi e continuità di ogni piano. |
| Motion control | Un riferimento performativo o di movimento è centrale. | Quale componente trasferire e quali caratteristiche conservare. |
| Lipsync | Un personaggio deve pronunciare un testo. | Audio, articolazione, intenzione recitativa e sincronizzazione. |

In image-to-video il prompt può concentrarsi sul cambiamento, evitando di riscrivere dettagli già chiari o di contraddire l’immagine. Per start/end frame, due immagini belle ma spazialmente incompatibili possono richiedere una trasformazione indesiderata. Se il multi-shot non offre controllo sufficiente, progettare e generare i piani separatamente, poi montarli.

La scelta finale dipende dalle funzioni effettivamente disponibili nello strumento. Durata, numero di reference, audio e controlli non vanno dedotti dal solo nome della modalità.

## 9. Luce, stile, suono e montaggio

Descrivere luce e stile attraverso caratteristiche osservabili: provenienza, direzione, morbidezza, contrasto, palette, materiali e profondità di campo. “Cinematic” può essere un’indicazione generale, ma non sostituisce queste decisioni. La profondità di campo dipende da più fattori, non soltanto dal numero di millimetri della lente. [M08, pp. 43–55; R11]

Il colore può diventare una convenzione interna al racconto. In *Absence*, presente monocromatico e memoria a colori funzionano perché la relazione è stabilita dalla sequenza. Non convertirla in “bianco e nero uguale tristezza”. [M08, pp. 91–93, 109]

L’audio determina anche ciò che si percepisce fuori campo. Progettare dialoghi, ambiente, rumori, musica e silenzi in relazione all’immagine. Una porta inquadrata dopo un rumore diverso produce un’attesa diversa. L’Academy Museum evidenzia il contributo congiunto di suono e immagine all’immersione emotiva. [R12]

Nel montaggio verificare sguardi, direzione sullo schermo, posizione degli oggetti e prosecuzione dei gesti. L’asse dei 180° è uno strumento di orientamento; attraversarlo può essere deliberato, ma occorre valutarne l’effetto. [R13, R14]

Ogni taglio deve avere una funzione. Hitchcock descrive come dettagli, sguardi e reazioni costruiscano la tensione: un oggetto acquista significato anche attraverso chi lo osserva e quando. Questo rende insufficiente valutare i piani uno per uno. [R15]

## 10. Architettura del prompt

Il seguente modello organizza la scrittura del prompt in linguaggio naturale ed è una proposta di sintesi, non un formato obbligatorio.

```text
INTENZIONE DI REGIA
Che cosa cambia nella scena e che cosa deve percepire lo spettatore.

CONTINUITÀ E REFERENCE
Identità, abiti, oggetti, ambiente e caratteristiche da preservare.
Ruolo di ciascuna reference.

STATO INIZIALE
Composizione, scala, posizione della camera, pose e luce.

AZIONE
Gesto principale e reazione osservabile.
Eventuali movimenti ambientali pertinenti.

CAMERA E FUOCO
Immobilità oppure traiettoria motivata.
Avvio, velocità, arresto e composizione finale.
Eventuale cambio di fuoco.

TEMPO E SUONO
Durata indicativa, beat, pause, dialoghi e ambiente sonoro.

STATO FINALE E RACCORDO
Risultato visivo e narrativo; relazione con il piano successivo.
```

La scheda completa serve a progettare. Il prompt inviato al modello deve contenere le informazioni pertinenti alla modalità scelta, senza ripetizioni. Se il progetto viene sviluppato in italiano e poi tradotto, preservare prima di tutto relazioni spaziali, tempi e intenzione. Non assumere che l’inglese sia sempre obbligatorio. [M08, pp. 49–55]

## 11. Esempio integrato: dalla scelta narrativa alla clip

Esempio originale, distinto dai prompt del docente.

**Intenzione:** far percepire l’assenza attraverso un’abitudine interrotta. La protagonista prepara due tazze, ma esita davanti alla seconda. L’informazione deve emergere dal gesto, senza spiegarla con una frase.

**Immagine guida:** mezzo busto di una donna seduta al tavolo, con entrambe le tazze leggibili. La seconda sedia resta visibile sul lato opposto. Luce morbida da una finestra laterale. L’inquadratura deve lasciare spazio alla mano per avvicinarsi alla tazza. Non occorre accentuare preventivamente la tristezza del volto.

**Prompt image-to-video proposto:**

> Mantieni identità, abiti, disposizione del tavolo e luce dell’immagine di riferimento. Un’unica inquadratura di circa sette secondi, camera completamente ferma. La donna guarda la seconda tazza e allunga lentamente la mano verso il manico. Prima di toccarlo, interrompe il gesto. Le dita restano sospese per un momento, poi si rilassano leggermente. La tazza resta immobile. Il respiro è appena percepibile. Conserva la pausa finale e la composizione iniziale.

**Raccordo:** un dettaglio successivo può riprendere la mano nella stessa posizione e completarne il ritiro. Se il raccordo non regge, usare il piano continuo oppure riprogettare il punto del taglio. L’ambiente sonoro si aggiunge o si genera secondo le capacità del percorso scelto.

L’esempio applica la semplicità d’azione del modulo 09, l’uso narrativo degli oggetti del modulo 08 e il principio della ricerca secondo cui la camera non deve muoversi per rendere emotiva una scena.

## 12. Precisazioni e correzioni rispetto alle slide

| Punto nei materiali | Precisazione adottata |
|---|---|
| M08, pp. 42–43: titolo con cinque elementi, seguito da quattro categorie. | Conservare le quattro categorie esplicitate; trattare intenzione, composizione e azione come ulteriori decisioni, senza attribuire alla slide una tassonomia univoca. |
| M09, p. 12: corrispondenze fra movimento ed emozione. | Sono possibilità espressive condizionate dal contesto. Un tilt discendente non significa necessariamente resa. |
| M09, p. 15: pan e tilt descritti con formule generiche di spostamento; tracking associato al seguito laterale. | Distinguere rotazione da traslazione. Il following può avvenire anche davanti o dietro al soggetto. |
| M09, p. 13: “Random shot” associato alla macchina a mano. | Usare handheld specificando oscillazione e intenzione; non equiparare camera a mano e casualità. |
| M09, p. 32: realismo attribuito al micro-movimento. | I microgesti contribuiscono, insieme a fisica, contatto, anatomia e continuità. |
| M09, pp. 44–49: controllo totale o transizione coerente presentati in termini assoluti. | Reference e frame guida sono vincoli utili; il risultato intermedio va controllato. |
| M09, p. 50: aggiungere movimento per rendere cinematografica la transizione. | Il movimento è facoltativo: sceglierlo solo se serve. |
| M09, p. 88: “medium shot” associato al corpo intero. | Se serve l’intero corpo, scrivere figura intera/full shot. |
| M09, pp. 86–90: numerose azioni, tagli e trasformazioni in prompt estesi. | Trattarli come progetti di sequenza; adattarli alla capacità del generatore o suddividerli in piani. |
| M08 e M09: prestazioni, versioni e limiti numerici di modelli commerciali. | Non assumerli come dati verificati o invarianti. Mantenerli fuori dalle regole permanenti. |

Le slide citano, tra gli altri, Nano Banana 2.1, Images2.5, Soul 2, Flux.3, Seedance 2.0/2.5 e Kling 4.0. Qui sono registrati come denominazioni presenti nei materiali, non come attestazione della loro disponibilità o delle prestazioni dichiarate. Prima di preparare una guida specifica a uno strumento, verificare nome, versione, limiti e funzioni nella documentazione ufficiale corrente.

## 13. Revisione e criteri di qualità

Valutare prima il racconto, poi la continuità e infine la rifinitura. Per ogni tentativo annotare il problema e la modifica introdotta; quando possibile cambiare una variabile alla volta. Questo rende interpretabile il confronto fra versioni e limita rigenerazioni senza criterio. È un’estensione operativa delle indicazioni produttive del modulo 08. [M08, pp. 16–24]

Una clip è pronta quando il gesto è leggibile, la camera realizza il comportamento voluto, l’identità rimane coerente e la durata consente di percepire il cambiamento. La sequenza è pronta quando i raccordi funzionano, l’audio sostiene il punto di vista e non ci sono piani ridondanti.

Checklist finale:

- La scena produce un cambiamento narrativo identificabile?
- Il prompt distingue soggetto, camera e ambiente?
- Scala, angolazione e movimento sono compatibili?
- Il frame iniziale consente l’azione richiesta?
- Mani, sguardi, oggetti e direzioni restano coerenti?
- Tempi e pause sono plausibili e le durate tornano?
- Gli effetti emotivi sono motivati nel contesto?
- Il risultato funziona anche accostato ai piani vicini?
- Le funzioni richieste sono supportate dallo strumento scelto?

## Fonti e tracciabilità

### Materiali didattici forniti

- **M08** — Accursio Graffeo, *08. Futura AI – TAG – Storyboard AI*, 129 pagine. [PDF originale](</Users/alessiamatteucci/Downloads/08.Futura AI - TAG - Storyboard AI _ Accursio Graffeo.pdf>).
- **M09** — Accursio Graffeo, *09. Futura AI – TAG – Introduzione al video AI*, 121 pagine. [PDF originale](</Users/alessiamatteucci/Downloads/09.Futura AI - TAG - Introduzione al video AI _ Accursio Graffeo.pdf>).

I numeri di pagina indicano l’ordine delle pagine nei PDF. Esempi e schemi indicati come originali o proposti sono elaborazioni di questo documento.

### Ricerca online precedente

- **R1** — M. David Mullen, ASC, [When to Move the Camera and Why](https://studentfilmmakers.com/notes-on-camera-movement-when-to-move-the-camera-and-why-by-m-david-mullen-asc/). Motivazione del movimento.
- **R2** — Yale, [Cinematography](https://filmanalysis.yale.edu/cinematography/). Lessico e analisi delle inquadrature.
- **R3** — Chief Sealth International High School, [Cinematic Elements: Shots](https://chiefsealthhs.seattleschools.org/academics/library/cinematic-elements-2/cinematic-elements/). Dimensione e informazione visiva.
- **R4** — Cores-Sarría e colleghi, [Danger, Sex, and Everything Else](https://aquila.usm.edu/fac_pubs/18931/). Studio su distanza, angolazione e risposta emotiva a fotografie.
- **R5** — Film Education, [Terminology](https://www.filmeducation.org.uk/resources/secondary/teaching_with_film/film_in_the_classroom/terminology/). Convenzioni introduttive.
- **R6** — Video Production Handbook, [Camera Movements](https://human.libretexts.org/Bookshelves/Theater_Film_and_Storytelling/Video_Production_Handbook/08%3A_Video_Aesthetics/8.03%3A_Camera_Movements). Definizioni geometriche.
- **R7** — Nashville Film Institute, [Camera Movements](https://www.nfi.edu/camera-movements-s46-backup/). Tipologie di movimento.
- **R8** — Sony, [Focal Length, Angle of View & Perspective](https://www.sony.co.uk/electronics/focal-length-angle-of-view-perspective). Focale e prospettiva.
- **R9** — StudioBinder, [The Dolly Zoom Shot](https://www.studiobinder.com/camera-shots/camera-movements/dolly-zoom-shot/). Tecnica combinata.
- **R10** — Malcolm Turvey, [Can the science of mirror neurons explain the power of camera movement?](https://www.davidbordwell.net/blog/2020/05/03/can-the-science-of-mirror-neurons-explain-the-power-of-camera-movement-a-guest-post-by-malcolm-turvey/). Limiti delle generalizzazioni sul coinvolgimento.
- **R11** — ZEISS, [Depth of Field and Bokeh](https://lenspire.zeiss.com/photo/app/uploads/2022/02/technical-article-depth-of-field-and-bokeh.pdf). Profondità di campo.
- **R12** — Academy Museum, [Sound](https://www.academymuseum.org/en/exhibitions/sound). Relazione fra immagine e suono.
- **R13** — Yale, [Editing](https://filmanalysis.yale.edu/editing/). Montaggio e continuità.
- **R14** — Filmmakers Academy, [Camera Composition: 180-Degree Rule](https://www.filmmakersacademy.com/blog-camera-180-degree-rule/). Orientamento spaziale e deviazione intenzionale.
- **R15** — Alfred Hitchcock, BFI, [My Own Methods](https://www.bfi.org.uk/sight-and-sound/features/alfred-hitchcock-my-own-methods). Costruzione dell’informazione e della tensione.

Questa guida integra principi cinematografici e prassi didattiche. Non è un confronto aggiornato fra prodotti né una promessa di risultati identici fra modelli generativi.
